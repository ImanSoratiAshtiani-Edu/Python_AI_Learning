from __future__ import annotations
import numpy as np

def even_numbers(n: int) -> np.ndarray:
    """اعداد زوج 0..n-1 را به صورت آرایه NumPy برمی‌گرداند."""
    a = np.arange(n)
    return a[a % 2 == 0]
