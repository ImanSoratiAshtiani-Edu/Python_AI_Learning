from __future__ import annotations
from .arrays import even_numbers

def main() -> None:
    print(even_numbers(10))
